import processing.core.PApplet;

public class Plantilla extends PApplet{

	public static void main(String[] args) {

PApplet.main("Plantilla");

	}

	@Override
	public void settings() {
	
		
		
	}
	
	
	@Override
	public void setup() {
		
		
		
		
	}
	
	@Override
	public void draw() {
	
		
		
	}
	
	
}
